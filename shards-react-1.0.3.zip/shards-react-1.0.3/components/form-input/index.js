import FormInput from "./FormInput";

export default FormInput;
