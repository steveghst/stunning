# Changelog

All notable changes to this project will be documented in this file.

## [1.0.1] - 2018-12-29

### Added
- Added missing `onChange` handler for the `FormCheckbox` component and updated docs.
- Added missing `onChange` handler for the `FormRadio` component and updated docs.

## [1.0.0] - 2018-12-28

- Initial release.
